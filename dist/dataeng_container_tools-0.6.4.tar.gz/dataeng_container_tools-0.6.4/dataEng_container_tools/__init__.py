from .safe_stdout import setup_default_stdout

setup_default_stdout()
