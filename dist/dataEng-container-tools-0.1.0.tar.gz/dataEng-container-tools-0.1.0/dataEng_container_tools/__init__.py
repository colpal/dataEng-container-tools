#python3 setup.py sdist bdist_wheel
from .safe_stdout import setup_default_stdout

setup_default_stdout()